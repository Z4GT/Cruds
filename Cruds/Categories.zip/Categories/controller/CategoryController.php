<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../model/CategoryModel.php';
session_start();

$categoryModel = new CategoryModel();
$option = isset($_REQUEST['option']) ? $_REQUEST['option'] : '';

switch ($option) {
    case 'list':
        $list = $categoryModel->getCategories();
        $_SESSION['list'] = serialize($list);
        header('Location: ../view/index.php');
        break;
    case 'create':
        header('Location: ../view/create.php');
        break;
    case 'store':
        $id = $_REQUEST['id'];
        $name = $_REQUEST['name'];
        $description = $_REQUEST['description'];
        $categoryModel->createCategory($id, $name, $description);
        header('Location: ../controller/CategoryController.php?option=list');
        break;
    case 'edit':
        $id = $_REQUEST['id'];
        $category = $categoryModel->getCategory($id);
        $_SESSION['category'] = $category;
        header('Location: ../view/edit.php');
        break;
    case 'update':
        $id = $_REQUEST['id'];
        $name = $_REQUEST['name'];
        $description = $_REQUEST['description'];
        $categoryModel->updateCategory($id, $name, $description);
        header('Location: ../controller/CategoryController.php?option=list');
        break;
    case 'delete':
        $id = $_REQUEST['id'];
        $categoryModel->deleteCategory($id);
        header('Location: ../controller/CategoryController.php?option=list');
        break;
    case 'search':
        $searchTerm = $_REQUEST['search'];
        $list = $categoryModel->searchCategories($searchTerm);
        $_SESSION['list'] = serialize($list);
        header('Location: ../view/index.php');
        break;
    default:
        header('Location: ../view/index.php');
}
?>
