<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Categoría</title>
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.css">
</head>

<body>
    <h3>Crear nueva categoría</h3>
    <form action="../controller/CategoryController.php" method="post">
        <input type="hidden" value="store" name="option">
        <label>ID:</label>
        <input type="text" name="id" required>
        <label>Nombre:</label>
        <input type="text" name="name" required>
        <label>Descripción:</label>
        <input type="text" name="description" required>
        <input type="submit" value="Crear">
    </form>
</body>

</html>