<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Categoría</title>
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.css">
</head>

<body>
    <h3>Actualizar categoría</h3>
    <?php
    include_once '../model/Category.php';
    session_start();
    $category = $_SESSION['category'];
    ?>
    <form action="../controller/CategoryController.php" method="post">
        <input type="hidden" value="update" name="option">
        <input type="hidden" value="<?php echo $category->getId(); ?>" name="id">
        <label>Nombre:</label>
        <input type="text" name="name" required value="<?php echo $category->getName(); ?>">
        <label>Descripción:</label>
        <input type="text" name="description" required value="<?php echo $category->getDescription(); ?>">
        <input type="submit" value="Actualizar">
    </form>
</body>

</html>