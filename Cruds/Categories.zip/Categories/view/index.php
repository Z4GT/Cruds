<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Categorías</title>
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.css">
</head>

<body>
    <h3>CRUD Categorías</h3>

    <!-- Formulario para buscar categorías -->
    <form action="../controller/CategoryController.php" method="post">
        <input type="hidden" value="search" name="option">
        <label for="search">Buscar categoría:</label>
        <input type="text" name="search" id="search" required>
        <input type="submit" value="Buscar">
    </form>

    <!-- Botones para listar y crear categorías -->
    <table>
        <tr>
            <td>
                <form action="../controller/CategoryController.php" method="post">
                    <input type="hidden" value="list" name="option">
                    <input type="submit" value="Consultar listado">
                </form>
            </td>
            <td>
                <form action="../controller/CategoryController.php" method="post">
                    <input type="hidden" value="create" name="option">
                    <input type="submit" value="Crear categoría">
                </form>
            </td>
        </tr>
    </table>

    <!-- Tabla para mostrar las categorías -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Eliminar</th>
                <th>Actualizar</th>
            </tr>
        </thead>
        <tbody>
            <?php
session_start();
include_once '../model/Category.php';

// Verificamos si existe en sesión el listado de categorías
if (isset($_SESSION['list'])) {
    $list = unserialize($_SESSION['list']);
    foreach ($list as $category) {
        echo "<tr>";
        echo "<td>" . $category->getId() . "</td>";
        echo "<td>" . $category->getName() . "</td>";
        echo "<td>" . $category->getDescription() . "</td>";
        // Opciones para eliminar y actualizar
        echo "<td><a href='../controller/CategoryController.php?option=delete&id=" . $category->getId() . "'>eliminar</a></td>";
        echo "<td><a href='../controller/CategoryController.php?option=edit&id=" . $category->getId() . "'>actualizar</a></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5'>No se han cargado datos.</td></tr>";
}
?>
        </tbody>
    </table>
</body>

</html>