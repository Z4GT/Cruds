<?php

include 'Database.php';
include 'Category.php';

class CategoryModel {
    public function getCategories() {
        $pdo = Database::connect();
        $sql = 'SELECT * FROM inv_categories ORDER BY name';
        $result = $pdo->query($sql);
        $list = [];
        foreach ($result as $row) {
            $category = new Category();
            $category->setId($row['id']);
            $category->setName($row['name']);
            $category->setDescription($row['description']);
            $list[] = $category;
        }
        Database::disconnect();
        return $list;
    }

    public function getCategory($id) {
        $pdo = Database::connect();
        $sql = 'SELECT * FROM inv_categories WHERE id = ?';
        $q = $pdo->prepare($sql);
        $q->execute([$id]);
        $row = $q->fetch(PDO::FETCH_ASSOC);
        $category = new Category();
        $category->setId($row['id']);
        $category->setName($row['name']);
        $category->setDescription($row['description']);
        Database::disconnect();
        return $category;
    }

    public function createCategory($id, $name, $description) {
        $pdo = Database::connect();
        $sql = 'INSERT INTO inv_categories (id, name, description) VALUES (?, ?, ?)';
        $q = $pdo->prepare($sql);
        $q->execute([$id, $name, $description]);
        Database::disconnect();
    }

    public function updateCategory($id, $name, $description) {
        $pdo = Database::connect();
        $sql = 'UPDATE inv_categories SET name = ?, description = ? WHERE id = ?';
        $q = $pdo->prepare($sql);
        $q->execute([$name, $description, $id]);
        Database::disconnect();
    }

    public function deleteCategory($id) {
        $pdo = Database::connect();
        $sql = 'DELETE FROM inv_categories WHERE id = ?';
        $q = $pdo->prepare($sql);
        $q->execute([$id]);
        Database::disconnect();
    }

    public function searchCategories($searchTerm) {
        $pdo = Database::connect();
        $sql = 'SELECT * FROM inv_categories WHERE name LIKE ? OR description LIKE ?';
        $q = $pdo->prepare($sql);
        $searchTerm = "%$searchTerm%";
        $q->execute([$searchTerm, $searchTerm]);
        $list = [];
        foreach ($q as $row) {
            $category = new Category();
            $category->setId($row['id']);
            $category->setName($row['name']);
            $category->setDescription($row['description']);
            $list[] = $category;
        }
        Database::disconnect();
        return $list;
    }
}
?>
