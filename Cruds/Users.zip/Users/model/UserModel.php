<?php

include 'Database.php';
include 'User.php';

class UserModel {
    public function getUsers() {
        $pdo = Database::connect();
        $sql = 'SELECT * FROM contr_users ORDER BY name';
        $result = $pdo->query($sql);
        $list = [];
        foreach ($result as $row) {
            $user = new User();
            $user->setId($row['id']);
            $user->setName($row['name']);
            $user->setLastName($row['last_name']);
            $user->setEmail($row['email']);
            $user->setPassword($row['password']);
            $user->setStatus($row['status']);
            $list[] = $user;
        }
        Database::disconnect();
        return $list;
    }

    public function getUser($id) {
        $pdo = Database::connect();
        $sql = 'SELECT * FROM contr_users WHERE id = ?';
        $q = $pdo->prepare($sql);
        $q->execute([$id]);
        $row = $q->fetch(PDO::FETCH_ASSOC);
        $user = new User();
        $user->setId($row['id']);
        $user->setName($row['name']);
        $user->setLastName($row['last_name']);
        $user->setEmail($row['email']);
        $user->setPassword($row['password']);
        $user->setStatus($row['status']);
        Database::disconnect();
        return $user;
    }

    public function createUser($id, $name, $lastName, $email, $password, $status) {
        $pdo = Database::connect();
        $sql = 'INSERT INTO contr_users (id, name, last_name, email, password, status) VALUES (?, ?, ?, ?, ?, ?)';
        $q = $pdo->prepare($sql);
        $q->execute([$id, $name, $lastName, $email, $password, $status]);
        Database::disconnect();
    }

    public function updateUser($id, $name, $lastName, $email, $password, $status) {
        $pdo = Database::connect();
        $sql = 'UPDATE contr_users SET name = ?, last_name = ?, email = ?, password = ?, status = ? WHERE id = ?';
        $q = $pdo->prepare($sql);
        $q->execute([$name, $lastName, $email, $password, $status, $id]);
        Database::disconnect();
    }

    public function deleteUser($id) {
        $pdo = Database::connect();
        $sql = 'DELETE FROM contr_users WHERE id = ?';
        $q = $pdo->prepare($sql);
        $q->execute([$id]);
        Database::disconnect();
    }

    public function searchUsers($searchTerm) {
        $pdo = Database::connect();
        $sql = 'SELECT * FROM contr_users WHERE name LIKE ? OR last_name LIKE ? OR email LIKE ?';
        $q = $pdo->prepare($sql);
        $searchTerm = "%$searchTerm%";
        $q->execute([$searchTerm, $searchTerm, $searchTerm]);
        $list = [];
        foreach ($q as $row) {
            $user = new User();
            $user->setId($row['id']);
            $user->setName($row['name']);
            $user->setLastName($row['last_name']);
            $user->setEmail($row['email']);
            $user->setPassword($row['password']);
            $user->setStatus($row['status']);
            $list[] = $user;
        }
        Database::disconnect();
        return $list;
    }
}
?>
