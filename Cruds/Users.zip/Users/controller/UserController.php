<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../model/UserModel.php';
session_start();

$userModel = new UserModel();
$option = isset($_REQUEST['option']) ? $_REQUEST['option'] : '';

switch ($option) {
    case 'list':
        $list = $userModel->getUsers();
        $_SESSION['list'] = serialize($list);
        header('Location: ../view/index.php');
        break;
    case 'create':
        header('Location: ../view/create.php');
        break;
    case 'store':
        $id = $_REQUEST['id'];
        $name = $_REQUEST['name'];
        $lastName = $_REQUEST['last_name'];
        $email = $_REQUEST['email'];
        $password = $_REQUEST['password'];
        $status = isset($_REQUEST['status']) ? 1 : 0;
        $userModel->createUser($id, $name, $lastName, $email, $password, $status);
        header('Location: ../controller/UserController.php?option=list');
        break;
    case 'edit':
        $id = $_REQUEST['id'];
        $user = $userModel->getUser($id);
        $_SESSION['user'] = $user;
        header('Location: ../view/edit.php');
        break;
    case 'update':
        $id = $_REQUEST['id'];
        $name = $_REQUEST['name'];
        $lastName = $_REQUEST['last_name'];
        $email = $_REQUEST['email'];
        $password = $_REQUEST['password'];
        $status = isset($_REQUEST['status']) ? 1 : 0;
        $userModel->updateUser($id, $name, $lastName, $email, $password, $status);
        header('Location: ../controller/UserController.php?option=list');
        break;
    case 'delete':
        $id = $_REQUEST['id'];
        $userModel->deleteUser($id);
        header('Location: ../controller/UserController.php?option=list');
        break;
    case 'search':
        $searchTerm = $_REQUEST['search'];
        $list = $userModel->searchUsers($searchTerm);
        $_SESSION['list'] = serialize($list);
        header('Location: ../view/index.php');
        break;
    default:
        header('Location: ../view/index.php');
}
?>
