<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Usuario</title>
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.css">
</head>

<body>
    <h3>Actualizar usuario</h3>
    <?php
include_once '../model/User.php';
session_start();
$user = $_SESSION['user'];
?>
    <form action="../controller/UserController.php" method="post">
        <input type="hidden" value="update" name="option">
        <input type="hidden" value="<?php echo $user->getId(); ?>" name="id">
        <label>Nombre:</label>
        <input type="text" name="name" required value="<?php echo $user->getName(); ?>">
        <label>Apellido:</label>
        <input type="text" name="last_name" required value="<?php echo $user->getLastName(); ?>">
        <label>Email:</label>
        <input type="email" name="email" required value="<?php echo $user->getEmail(); ?>">
        <label>Password:</label>
        <input type="password" name="password" required value="<?php echo $user->getPassword(); ?>">
        <label>Status:</label>
        <input type="checkbox" name="status" <?php echo $user->getStatus() ? 'checked' : ''; ?>><br>
        <input type="submit" value="Actualizar">
    </form>
</body>

</html>