<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Usuarios</title>
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.css">
</head>

<body>
    <h3>CRUD Usuarios</h3>

    <!-- Formulario para buscar usuarios -->
    <form action="../controller/UserController.php" method="post">
        <input type="hidden" value="search" name="option">
        <label for="search">Buscar usuario:</label>
        <input type="text" name="search" id="search" required>
        <input type="submit" value="Buscar">
    </form>

    <!-- Botones para listar y crear usuarios -->
    <table>
        <tr>
            <td>
                <form action="../controller/UserController.php" method="post">
                    <input type="hidden" value="list" name="option">
                    <input type="submit" value="Consultar listado">
                </form>
            </td>
            <td>
                <form action="../controller/UserController.php" method="post">
                    <input type="hidden" value="create" name="option">
                    <input type="submit" value="Crear usuario">
                </form>
            </td>
        </tr>
    </table>

    <!-- Tabla para mostrar los usuarios -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Email</th>
                <th>Status</th>
                <th>Eliminar</th>
                <th>Actualizar</th>
            </tr>
        </thead>
        <tbody>
            <?php
session_start();
include_once '../model/User.php';

// Verificamos si existe en sesión el listado de usuarios
if (isset($_SESSION['list'])) {
    $list = unserialize($_SESSION['list']);
    foreach ($list as $user) {
        echo "<tr>";
        echo "<td>" . $user->getId() . "</td>";
        echo "<td>" . $user->getName() . "</td>";
        echo "<td>" . $user->getLastName() . "</td>";
        echo "<td>" . $user->getEmail() . "</td>";
        echo "<td>" . ($user->getStatus() ? 'Activo' : 'Inactivo') . "</td>";
        // Opciones para eliminar y actualizar
        echo "<td><a href='../controller/UserController.php?option=delete&id=" . $user->getId() . "'>eliminar</a></td>";
        echo "<td><a href='../controller/UserController.php?option=edit&id=" . $user->getId() . "'>actualizar</a></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7'>No se han cargado datos.</td></tr>";
}
?>
        </tbody>
    </table>
</body>

</html>