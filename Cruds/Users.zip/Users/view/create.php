<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Usuario</title>
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.css">
</head>

<body>
    <h3>Crear nuevo usuario</h3>
    <form action="../controller/UserController.php" method="post">
        <input type="hidden" value="store" name="option">
        <label>ID:</label>
        <input type="text" name="id" required>
        <label>Nombre:</label>
        <input type="text" name="name" required>
        <label>Apellido:</label>
        <input type="text" name="last_name" required>
        <label>Email:</label>
        <input type="email" name="email" required>
        <label>Password:</label>
        <input type="password" name="password" required>
        <label>Status:</label>
        <input type="checkbox" name="status"><br>
        <input type="submit" value="Crear">
    </form>
</body>

</html>